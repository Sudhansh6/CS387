https://chineduorie.com/posts/how-to-use-sequelize-on-an-existing-database
https://www.bezkoder.com/node-express-sequelize-postgresql/
https://www.bezkoder.com/angular-13-pagination-ngx/
https://www.bezkoder.com/angular-13-crud-example/
https://www.bezkoder.com/angular-node-express-postgresql/