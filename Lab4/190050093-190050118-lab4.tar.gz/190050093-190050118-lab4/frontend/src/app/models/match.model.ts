export class Match {
    match_id?:any;
}
