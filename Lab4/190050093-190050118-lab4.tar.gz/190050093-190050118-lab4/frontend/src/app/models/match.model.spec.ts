import { Match } from './match.model';

describe('Match', () => {
  it('should create an instance', () => {
    expect(new Match()).toBeTruthy();
  });
});
